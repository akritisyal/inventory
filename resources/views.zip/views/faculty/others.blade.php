@extends('app')
    @section('list-item')
              <li class="nav-item">
                <a class="nav-link active" href="/welcome">
                  <span data-feather="home"></span>
                  Dashboard
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="/welcome">
                  <span data-feather="file-text"></span>
                  Reports
                </a>
              </li>
    @endsection
@section('content')

@endsection