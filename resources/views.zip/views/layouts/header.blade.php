<header>
<div class="container d-flex bd-highlight mb-3">
  <div class="headertop mr-auto p-1 bd-highlight"><h1>Inventory Manager
      <div style="font-size:15px;"><em>Indira Gandhi Delhi Technical University for Women</em></div>
  </h1></div>
  <div class="headertop p-2 bd-highlight"><a class="btn btn-primary" href="/applications">Switch Apps</a></div>
  <div class="p-2 bd-highlight">
  <!-- <button type="button" class="btn btn-primary" data-toggle="button" aria-pressed="false" autocomplete="off">
  Single toggle
</button> -->
      <button class="btn btn-outline-primary" onClick="toggleSidebar()">
      <i class="fa fa-user"></i> &nbsp;
      <span><?php echo $user; ?></span>
<script>
    function toggleSidebar(){
      document.getElementById("sidebar").classList.toggle('active');
    }
</script>
  </button>
  <div id="sidebar">
<ul>
  <li> View Profile</li>
  <li>Settings</li>
  <li>Log Out</li>
</ul>
</div>
</div>
</div>
<nav class="d-flex justify-content-center">
  <a class="btn btn-outline-light" href="/home">Home</a> &nbsp;
  <a class="btn btn-outline-light" href="/orders">Orders</a>&nbsp;
  <a class="btn btn-outline-light" href="/others">Others</a>
</nav>
</header>